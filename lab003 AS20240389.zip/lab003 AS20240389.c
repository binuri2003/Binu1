#include <stdio.h>
#include <stdlib.h>

int main()
{


    int s1 = (8+3);
    int s2 = 11*2;
    int s3 = 10/2;
    int s4 = 5*7;
    int s5 = 4%3;
    int s6 = 22-35;
    int s7 = -13+1;

    printf("(8+3)*2-10/2*7+4%3\n");
    printf("Step 1 is %d\n", s1);
    printf("Step 2 is %d\n", s2);
    printf("Step 3 is %d\n", s3);
    printf("Step 4 is %d\n", s4);
    printf("Step 5 is %d\n", s5);
    printf("Step 6 is %d\n", s6);
    printf("Step 7 is %d\n", s7);

//Activity 2
  int x = 10,y = 20;

   int greaterThan = x>y;
   int lessThan = x<y;
   int equalTo = x==y;
   int nonEqual = x!=y;
   int equalGreaterThan = x>=y;
   int equalLessThan = x<=y;

   printf("x > y: %d\n",greaterThan);
   printf("x < y: %d\n",lessThan);
   printf("x == y: %d\n",equalTo);
   printf("x != y: %d\n",nonEqual);
   printf("x >= y: %d\n",equalGreaterThan);
   printf("x <= y: %d\n",equalLessThan);

//Activity 3

 int a = 5, b = 0;

   int logicalAnd = a&&b;
   int logicalOr = a||b;
   int logicalNot = !a;
   int logicalNott = !b;

   printf("a && b : %d\n",logicalAnd);
   printf("a || b : %d\n",logicalOr);
   printf("!a : %d\n",logicalNot);
   printf("!b : %d\n",logicalNott);


 int m = 6 , n = 3;

   int bitwiseAnd = m&n;
   int bitwiseOr = m|n;
   int bitwiseXor = m^n;
   int bitwiseNot = ~m;
   int leftShift = m<<1;
   int rightShift = m>>1;

   printf("m & n : %d\n",bitwiseAnd);
   printf("m | n : %d\n",bitwiseOr);
   printf("m ^ n : %d\n",bitwiseXor);
   printf("~m : %d\n",bitwiseNot);
   printf("m<<1 : %d\n",leftShift);
   printf("m>>1 : %d\n",rightShift);


//Activity 4

   int val = 10;

   int v2 = val+=5;
   int v3 = val-=3;
   int v4 = val*=2;
   int v5 = val/=4;
   int v6 = val%=3;

   printf("val += 5 :%d\n",v2);
   printf("val -= 3 :%d\n",v3);
   printf("val *= 2 :%d\n",v4);
   printf("val /= 4 :%d\n",v5);
   printf("val %= 3 :%d\n",v6);


//Activity 6

   int z = 4;

   int z2 =++z;
   int z3 =z++;
   int z4 =--z;
   int z5 =z--;
   int positive = -z;
   int notResult =!z;

   printf("++z :%d\n",z2);
   printf("z++ :%d\n",z3);
   printf("--z :%d\n",z4);
   printf("z-- :%d\n",z5);
   printf("Positive = -z :%d\n",positive);
   printf("NotResult = !z :%d\n",notResult);

//Activity 7

   int badgeActive;
   int pinCorrect ;
   int result;



   printf("If the badge is activated enter 1 ,else enter 0 :");
   scanf("%d", &badgeActive);
   printf("Is the pin correct :");
   scanf("%d",&pinCorrect);

   result = badgeActive||pinCorrect;
   printf("Result : %d\n",result);



//Activity 8










    return 0;
}
